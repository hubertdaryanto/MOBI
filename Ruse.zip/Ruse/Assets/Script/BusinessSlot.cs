﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BusinessSlot : MonoBehaviour
{
    [SerializeField] Image image;

    private Business _business;
    public Business business
    {
        get { return _business; }
        set
        //untuk menunjukkan icon secara automatik dari Business icon
        {
            _business = value;
            if (_business == null)
            {
                image.enabled = false;

            }
            else
            {
                image.sprite = _business.Picture;
                image.enabled = true;
            }
        }
    }

    private void OnValidate()
    {
        //untuk me-refresh icon Business saat menggantikan Business pada Business menu
        if (image == null)
        {
            image = GetComponent<Image>();
        }
    }
}
