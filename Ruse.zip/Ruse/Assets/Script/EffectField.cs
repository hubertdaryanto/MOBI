﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectField : MonoBehaviour
{
    [SerializeField] List<Season> Seasons;
    [SerializeField] Transform SeasonParent;
    [SerializeField] SeasonSlot[] Seasonslots;

    private void OnValidate()
    {
        if (SeasonParent != null)
        {
            Seasonslots = SeasonParent.GetComponentsInChildren<SeasonSlot>();
        }
        RefreshUI();
    }

    private void RefreshUI()
    {
        //untuk me-refresh icon Season saat menggantikan Season pada Season menu
        int i = 0;
        for (; i < Seasons.Count && i < Seasonslots.Length; i++)
        {
            Seasonslots[i].Season = Seasons[i];
        }
        for (; i < Seasonslots.Length; i++)
        {
            Seasonslots[i].Season = null;
        }
    }
}
