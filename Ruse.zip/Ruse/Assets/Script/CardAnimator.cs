﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardAnimation{
    Card card;
    Vector2 destination;
    Quaternion rotation;

    public CardAnimation(Card c, Vector2 pos)
    {
        card = c;
        destination = pos;
        rotation = Quartenion.identity;
    }

    public CardAnimation(Card c, Vector2 pos, Quartenion rot)
    {
        card = c;
        destination = pos;
        rotation = rot;
    }

    public bool Play()
    {
        bool finished = false;

        if(Vector2.Distance(card.transform.position, destination) < Constants.CARD_SNAP_DISTANCE)
        {
            card.transform.position = destination;
            finished = true;
        }
        else
        {
            card.transform.position = Vector2.MoveTowards(card.transform.position, destination, Constants.CARD_MOVEMENT_SPEED * Time.deltaTime);
            card.transform.rotation = Quartenion.Lerp(card.transform.rotation, rotation, Constants.CARD_ROTATION_SPEED * Time.deltaTime);
        }
        return finished;
    }
}


public class CardAnimator : MonoBehaviour
{
    public GameObject CardPrefab;
    public List<Card> DisplayingCards;
    Queue<CardAnimation> cardAnimations;
    CardAnimation currentCardAnimation;
    Vector2 startPosition = new Vector2(-5f, 1f):

    public UnityEvent OnAllAnimationFinished = new UnityEvent();
    bool working = false;

    void Awake()
    {
        cardAnimations = new Queue<CardAnimation>();
        InitializeDeck();
    }

    void InitializeDeck()
    {
        DisplayingCards = new List<Card>();
        
        for (byte value = 0; value < 52; value++)//angka 52 diganti sesuai berapa maksimal kartu di dalam deck
        {
            Vector2 newPosition = startPosition + Vector2.right * Constans.DECK_CARD_POSITION_OFFSET * value;
            GameObject newGameObject = Instantiate(CardPrefab, newPosition, Quartenion.identity);
            newGameObject.transform.parent = transform;
            Card card = newGameObject.GetComponent<Card>();
            card.SetDisplayingOrder(-1);
            card.transform.position = newPosition;
            DisplayingCards.Add(card);
        }
    }

    public Card TakeFirstDisplayingCard()
    {
        int numberOfDisplayingCard = DisplayingCards.Count;

        if(numberOfDisplayingCard > 0)
        {
            Card card = DisplayingCards[numberOfDisplayingCard - 1];
            DisplayingCards.Remove(card);
            return card;
        }
        return null;
    }

    public void DealDisplaingCards(Player player, int numberOfCard, bool animated = true)
    {
        int start = DisplayingCards.Count - 1;
        int finish = DisplayingCards.Count - 1 - numberOfCard;

        List<Card> cardsToRemoveFromDeck = new List<Card>();

        for(int i = start; i > finish; i--)
        {
            Card card = DisplayingCards[i];
            player.ReceiveDisplayingCard(card);
            cardsToRemoveFromDeck.Add(card);
            if(animated)
            {
                AddCardAnimation(card, player.NextCardPosition());
            }
            else
            {
                card.transform.position = player.NextCardPosition();   
            }
        }

        foreach(Card card in cardsToRemoveFromDeck)
        {
            DisplayingCards.Remove(card);
        }
    }

    public void DrawDisplayingCard(Player player)
    {
        int numberOfDisplayingCard = DisplayingCards.Count;
        if(numberOfDisplayingCard > 0)
        {
            Card card = DisplayingCards[numberOfDisplayingCard - 1];
            player.ReceiveDisplayingCard(card);
            AddCardAnimation(card, player.NextCardPosition());

            DisplayingCards.Remove(card);
        }
    }

    public void DrawDisplayingCard(Player player, byte value)
    {
        int numberOfDisplayingCard = DisplayingCards.Count;
        if(numberOfDisplayingCard > 0)
        {
            Card card = DisplayingCards[numberOfDisplayingCard - 1];
            card.SetCardValue(value);
            card.SetFaceUp(true);
            player.ReceiveDisplayingCard(card);
            AddCardAnimation(card, player.NextCardPosition());

            DisplayingCards.Remove(card);
        }
    }

    public void AddCardAnimation(Card card, Vector2 position)
    {
        CardAnimation ca = new CardAnimation(card, position);
        cardAnimations.Enqueue(ca);
        working = true;
    }


    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
