﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BusinessField : MonoBehaviour
{
    [SerializeField] List<Business> Businesss;
    [SerializeField] Transform BusinessParent;
    [SerializeField] BusinessSlot[] Businessslots;

    private void OnValidate()
    {
        if (BusinessParent != null)
        {
            Businessslots = BusinessParent.GetComponentsInChildren<BusinessSlot>();
        }
        RefreshUI();
    }

    private void RefreshUI()
    {
        //untuk me-refresh icon Business saat menggantikan Business pada Business menu
        int i = 0;
        for (; i < Businesss.Count && i < Businessslots.Length; i++)
        {
            Businessslots[i].business = Businesss[i];
        }
        for (; i < Businessslots.Length; i++)
        {
            Businessslots[i].business = null;
        }
    }
}
