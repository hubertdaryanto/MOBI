﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : IEquatable<Player>
{
    public string PlayerId;
    public Vector2 Position;
    public Vector2 BookPosition;

    int numberOfDisplayingCards;
    int numberOfBooks;

    public List<Card> DisplayingCards = new List<Card>();

    public Vector2 NextCardPosition()
    {
        Vector2 nextPos = Position + Vector2.right * Constans.PLAYER_CARD_POSITION_OFFSET * numberOfDisplayingCards;
        return nextPos;
    }

    public Vector2 NextBookPosition()
    {
        Vector2 nextPos = BookPosition + Vector2.right * Constans.PLAYER_BOOK_POSITION_OFFSET * numberOfBooks;
        return nextPos;
    }

    public void SetCardValues(List<byte> values)
    {
        if(DisplayingCards.Count != values.Count)
        {
            return;
        }
        for(int i = 0; i < values.Count;i++)
        {
            Card card = DisplayingCards[i];
            card.SetCardValue(values[i]);
            card.SetDisplayingOrder(i);
        }
    }

    public void HideCardValues()
    {
        foreach(Card card in DisplayingCards)
        {
            card.SetFaceUp(false);
        }
    }
    
    public void ShowCardValues()
    {
        foreach(Card card in DisplayingCards)
        {
            card.SetFaceUp(false);
        }
    }

    public void ReceiveDisplayingCard(Card card)
    {
        DisplayingCards.Add(card);
        card.OwnerId = PlayerId;
        numberOfDisplayingCards++;
    }

    public void ReceiveBook(Ranks rank, CardAnimator cardAnimator)
    {
        Vector2 targetPosition = NextBookPosition();
        List<Card> displayingCardsToRemove = new List<Card>();
        foreach(Card card in DisplayingCards)
        {
            if(card.Rank = rank)
            {
                card.SetFaceUp(true);
                float randomRotation = UnityEngine.Random.Range(-1 * Constants.BOOK_MAX_RANDOM_ROTATION, Constants.BOOK_MAX_RANDOM_ROTATION);
                cardAnimator.AddCardAnimation(card, targetPosition, Quarternion.Euler(Vector3.forward * randomRotation));
                displayingCardToRemove.Add(card);
            }
        }
        DisplayingCards.RemoveAll(card => displayingCardsToRemove.Contains(card));
        numberOfBooks++;
    }
    public void RestoreBook(Ranks rank, CardAnimator cardAnimator)
    {
        Vector2 targetPosition = NextBookPosition();

        for(int i = 0; i < 4; i++)
        {
            Card card = cardAnimator.TakeFirstDisplayingCard();
            int intRankValue = (int)rank;
            int cardValue = (intRankValue - 1) * 4 + i;
            card.SetCardValue((byte)cardValue);
            card.SetFaceUp(true);
            float randomRotation = UnityEngine.Random.Range(-1 * Constants.BOOK_MAX_RANDOM_ROTATION, Constants.BOOK_MAX_RANDOM_ROTATION);
            card.transform.position = targetPosition;
            card.transform.rotation = Quarternion.Euler(Vector3.forward * randomRotation);
        }
    }

    public void SendDisplayingCardToPlayer(Player receivingPlayer, CardAnimator cardAnimator, List<byte> cardValues, bool isLocalPlayer)
    {
        int playerDisplayingCardsCount = DisplayingCards.Count;

        if(playerDisplayingCardsCount < cardValues.Count)
        {
            Debug.LogError("not enough displaying cards");
            return;
        }
        for(int i = 0; i< cardValues.Count; i++)
        {
            Card card = null;
            byte cardValue = cardValues[i];

            if(isLocalPlayer)
            {
                foreach(Card c in DisplayingCards)
                {
                    if(c.Rank == Card.GetRank(cardValue) && c.Suit == Card.GetSuit(cardValue))
                    {
                        card = c;
                        break;
                    }
                }
            }
            else
            {
                card = DisplayingCards[playerDisplayingCardsCount - 1 - i];
                card.SetCardValue(cardValue);
                card.SetFaceUp(true);
            }
            if(card != null)
            {
                DisplayingCards.Remove(card);
                receivingPlayer.ReceiveDisplayingCard(card);
                cardAnimator.AddCardAnimation(card, receivingPlayer.NextCardPosition());
                numberOfDisplayingCards--;
            }

            else
            {
                Debug.LogError("Unable to find displaying card.");
            }
        }
        RepositionDisplayingCards(cardAnimator);
    }

    public bool Equals(Player other)
    {
        if(PlayerId.Equals(other.PlayerId))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
