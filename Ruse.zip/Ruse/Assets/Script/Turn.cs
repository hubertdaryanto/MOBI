﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity;
using UnityEngine.UI;

public class Turn : MonoBehaviour
{
    private GameObject player1, player2, player3, player4;
    // Start is called before the first frame update
    public enum GameState
        {
            Idle,
            GameStarted,
            TurnStarted,
            TurnSelectingNumber,
            TurnConfirmedSelectedNumber,
            TurnWaitingForOpponentConfirmation,
            TurnOpponentConfirmed,
            TurnGoFish,
            GameFinished
        };
    
    protected GameState gameState = GameState.GameStarted;
    void Start()
    {
        GameFlow();
    }

    public void GameFlow()
    {
        if (gameState > GameState.GameStarted)
        {
            CheckPlayersBooks();
            ShowAndHidePlayersDisplayingCards();

            if (gameDataManager.GameFinished())
            {
                gameState = GameState.GameFinished;
            }
        }
        switch(gameState)
        {
            case GameState.Idle:
            {
                break;
            }
            case GameState.GameStarted:
            {
                OnGameStarted();
                break;
            }
            case GameState.TurnStarted:
            {
                OnTurnStarted();
                break;
            }
            case GameState.TurnSelectingNumber:
            {
                OnTurnSelectingNumber();
                break;
            }
            case GameState.TurnConfirmedSelectedNumber:
            {
                OnTurnConfirmedSelectedNumber();
                break;
            }
            case GameState.TurnWaitingForOpponentConfirmation:
            {
                OnTurnWaitingForOpponentConfirmation();
                break;
            }
            case GameState.TurnOpponentConfirmed:
            {
                OnTurnOpponentConfirmed();
                break;
            }
            case GameState.GameFinished:
            {
                OnGameFinished();
                break;
            }
        }
    }

    protected virtual void OnGameStarted()
    {
        
    }
    protected virtual void OnTurnStarted()
    {
        SwitchTurn();
        gameState = GameState.TurnSelectingNumber;
        GameFlow();
    }
}
