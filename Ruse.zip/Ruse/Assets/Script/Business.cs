﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="Business",menuName ="Business")]
public class Business : ScriptableObject
{
    public string CardName;
    public int Tier;
    public int Income;
    public int Cost;
    public Sprite Picture;
    [TextArea(3, 30)]
    public string Description;
}
