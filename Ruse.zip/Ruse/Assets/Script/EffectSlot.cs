﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EffectSlot : MonoBehaviour
{
    [SerializeField] Image image;

    private Effect _Effect;
    public Effect Effect
    {
        get { return _Effect; }
        set
        //untuk menunjukkan icon secara automatik dari Effect icon
        {
            _Effect = value;
            if (_Effect == null)
            {
                image.enabled = false;

            }
            else
            {
                image.sprite = _Effect.Picture;
                image.enabled = true;
            }
        }
    }

    private void OnValidate()
    {
        //untuk me-refresh icon Effect saat menggantikan Effect pada Effect menu
        if (image == null)
        {
            image = GetComponent<Image>();
        }
    }
}
