﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="Effect",menuName ="Effect")]
public class Effect : ScriptableObject
{


    public string CardName;     //Nama
    public string CardType;     //tipe kartu
    public Sprite Symbol;       //simbol(atk,def,esp)
    public int Cost;            //Cost

    public Sprite Picture;         //Gambar

    [TextArea(3, 100)]          //Deskripsi
    public string Description;  //Deskripsi 

}
