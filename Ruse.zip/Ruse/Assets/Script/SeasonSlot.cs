﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SeasonSlot : MonoBehaviour
{
    [SerializeField] Image image;

    private Season _Season;
    public Season Season
    {
        get { return _Season; }
        set
        //untuk menunjukkan icon secara automatik dari Season icon
        {
            _Season = value;
            if (_Season == null)
            {
                image.enabled = false;

            }
            else
            {
                image.sprite = _Season.Picture;
                image.enabled = true;
            }
        }
    }

    private void OnValidate()
    {
        //untuk me-refresh icon Season saat menggantikan Season pada Season menu
        if (image == null)
        {
            image = GetComponent<Image>();
        }
    }
}
