﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*kalo kartu di klik, langsung kebayar cost nya 
kartu dari hand only
tar di update lagi function ini kalo perlu sih 
comment 0
 */
public class EffectCost : MonoBehaviour
{
    [SerializeField] Effect eff;
    Currency crr;

    public void pay()
    {
        if (eff.Cost > crr.currencyValue)
        {
            Debug.Log("Not enough gold");
            //tar taroh prompt window buat ini (comment 1)
        }
        else if (eff.Cost <= crr.currencyValue)
        {
            crr.currencyValue -= eff.Cost;
            //tar harus tambahin function call card to field yang ini (comment 2)
        }
    }
}
