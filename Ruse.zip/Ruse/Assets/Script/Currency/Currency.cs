﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//ini function nya attach ke gameobject text gold nya
public class Currency : MonoBehaviour
{
    public int currencyValue = 5000; //starting gold
    Text cText; //masukin gameobject text buat currency gold nya

    void Start()
    {
        cText = GetComponent<Text>();
    }

    void Update()
    {
        cText.text = "Gold = " + currencyValue;
    }

    public int getValue()
    {
        return currencyValue;
    }
}
