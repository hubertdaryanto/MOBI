﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//see comment 0 di effect cost
public class BusinessCost : MonoBehaviour
{
    [SerializeField] Business bsn;
    Currency crr;
    
    public void pay()
    {
        if(bsn.Cost > crr.currencyValue)
        {
            Debug.Log("Not enough gold");
            //see comment 1 di effect cost
        }
        else if (bsn.Cost <= crr.currencyValue)
        {
            crr.currencyValue -= bsn.Cost;
            //see comment 2 di effect cost
        }
    }
}
