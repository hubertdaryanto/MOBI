﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//penghasilan dari business card di field
//buat di semua gameobject field
public class Income : MonoBehaviour
{
    [SerializeField] List<Business> Lbsn;
    [SerializeField] BusinessSlot[] bsnSlot;
    Currency crr;

    public void addGold()
    {
        int total = 0;
        for(int i = 0; i < Lbsn.Count && i < bsnSlot.Length; i++)
        {
            total += Lbsn[i].Income; 
        }
        crr.currencyValue += total;
    }

    void Update()
    {
        //taroh if (fase beginning turn == true) addGold()
        addGold();
    }
}
