﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="Season",menuName ="Season")]
public class Season : ScriptableObject
{
    public string CardName;     //nama kartu

    public Sprite Picture;      //gambar kartu

    [TextArea(3, 30)]            //tmpt deskripsi kartu
    public string Description;
}
